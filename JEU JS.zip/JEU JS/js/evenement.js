function evenement(){
    if(position_player_x == 2 && position_player_y == 3){
      /* alert("Evenement !") */
      };
    if(position_player_x == 0 && position_player_y == 8){ /* && current_map == "xx" */
      /* alert("Sortie !") */
    }
  };

  /* position_x et position_y désigne l'emplacement du pnj sur la carte. */
class pnj{
  constructor(nom, image, position_x, position_y, image_map_ou_il_apparait, chiffre, identifiant){
    this.nom = nom;
    this.image = image;
    this.position_x = position_x;
    this.position_y = position_y;
    this.location = image_map_ou_il_apparait;
    this.chiffre = chiffre;
    this.identifiant = identifiant
  }
  pose_pnj(){
    if(image_map_actuelle == this.location){
    document.getElementById(this.identifiant).style.backgroundImage = 'url('+this.image+')'};
  }
  creer(){
    if(image_map_actuelle == this.location){
      pnj_test[this.position_x][this.position_y] = this.chiffre};
  }
  
}
